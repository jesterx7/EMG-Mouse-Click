var classplux_1_1_event_1_1_dig_in_update =
[
    [ "__init__", "classplux_1_1_event_1_1_dig_in_update.html#a408758fce70ecacf72374195e541e189", null ],
    [ "state", "classplux_1_1_event_1_1_dig_in_update.html#adf6855ac1d096e6b556a9d4d0b9cbde9", null ],
    [ "timestamp", "classplux_1_1_event_1_1_dig_in_update.html#a61db154dca5a64cf9a90d495a1e76786", null ]
];