var classplux_1_1_session =
[
    [ "__init__", "classplux_1_1_session.html#acccca7b108e20b784154fecfacbe46e1", null ],
    [ "baseFreq", "classplux_1_1_session.html#aef40228e8ec356f9b99c4af49fd1a08b", null ],
    [ "nFrames", "classplux_1_1_session.html#a11a6003c3eaaa7c7ad70ab341b34aadd", null ],
    [ "properties", "classplux_1_1_session.html#a5dd571440ce50d831528d217fb859b12", null ],
    [ "schedStartTime", "classplux_1_1_session.html#a4f347cb97395ff68682e54fbe10bbc04", null ],
    [ "sources", "classplux_1_1_session.html#af2b5347b4dc276d787030cc9b2787b2e", null ],
    [ "startTime", "classplux_1_1_session.html#ac9fb6cc84256431abd4318dbcd698260", null ],
    [ "text", "classplux_1_1_session.html#a4e871d2cf33e2622e302dd6d1853f16b", null ]
];