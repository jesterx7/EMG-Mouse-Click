var classplux_1_1_source_ex =
[
    [ "__init__", "classplux_1_1_source_ex.html#a4997dfbbc8fc1753226ab9e3bdc1ebc9", null ],
    [ "properties", "classplux_1_1_source_ex.html#a71e194d64fd45900c20b485fd4835de5", null ]
];