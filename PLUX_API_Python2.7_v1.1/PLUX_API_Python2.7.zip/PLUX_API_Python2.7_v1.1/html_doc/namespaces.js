var namespaces =
[
    [ "plux", "namespaceplux.html", "namespaceplux" ]
];