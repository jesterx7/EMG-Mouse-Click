var annotated =
[
    [ "plux", "namespaceplux.html", "namespaceplux" ]
];