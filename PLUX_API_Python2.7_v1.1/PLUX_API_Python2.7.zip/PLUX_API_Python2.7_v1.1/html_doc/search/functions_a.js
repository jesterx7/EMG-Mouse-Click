var searchData=
[
  ['setdout',['setDOut',['../classplux_1_1_signals_dev.html#add9a9cef292c8099162dfe7e54c0fc7d',1,'plux::SignalsDev']]],
  ['settime',['setTime',['../classplux_1_1_memory_dev.html#aa82bc298b5c3ff8d08aff418092c3cde',1,'plux::MemoryDev']]],
  ['settimeout',['setTimeout',['../classplux_1_1_base_dev.html#ae0f2928d449358701473c78bf91b56cf',1,'plux::BaseDev']]],
  ['start',['start',['../classplux_1_1_signals_dev.html#a8bd7270574dcc4b64b1818e3d4de9abe',1,'plux.SignalsDev.start'],['../classplux_1_1_signals_dev.html#a8bd7270574dcc4b64b1818e3d4de9abe',1,'plux.SignalsDev.start']]],
  ['stop',['stop',['../classplux_1_1_signals_dev.html#a535cff89f15c23dcaf0df287de2f945d',1,'plux::SignalsDev']]],
  ['stopsessionacq',['stopSessionAcq',['../classplux_1_1_memory_dev.html#aa31176d225a95289e271d174c7a2f7be',1,'plux::MemoryDev']]]
];
