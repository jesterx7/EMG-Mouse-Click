var searchData=
[
  ['diginupdate',['DigInUpdate',['../classplux_1_1_event_1_1_dig_in_update.html',1,'plux::Event']]],
  ['disconnect',['Disconnect',['../classplux_1_1_event_1_1_disconnect.html',1,'plux::Event']]]
];
