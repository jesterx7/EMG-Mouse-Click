var searchData=
[
  ['value',['value',['../classplux_1_1_event_1_1_clock.html#adf182fee350bc8ae362e79d948ddb940',1,'plux::Event::Clock']]],
  ['version',['version',['../namespaceplux.html#acf9bc4587ea9b0665da098e7e83f9bce',1,'plux']]]
];
