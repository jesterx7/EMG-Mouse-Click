var searchData=
[
  ['basefreq',['baseFreq',['../classplux_1_1_schedule.html#a35c29dd4c1fa6d259e1958d5089af2e0',1,'plux.Schedule.baseFreq()'],['../classplux_1_1_session.html#aef40228e8ec356f9b99c4af49fd1a08b',1,'plux.Session.baseFreq()']]],
  ['batdischarged',['BatDischarged',['../namespaceplux_1_1_event_1_1_disconnect_reason.html#a53abf885caf07e3b011ea61e79e4a744',1,'plux::Event::DisconnectReason']]],
  ['buttonpressed',['ButtonPressed',['../namespaceplux_1_1_event_1_1_disconnect_reason.html#a2ac4b3d633fae984c9175b5fd7328ad0',1,'plux::Event::DisconnectReason']]]
];
