var searchData=
[
  ['close',['close',['../classplux_1_1_base_dev.html#af79985152b5df3916e300c2e4c9a4f76',1,'plux::BaseDev']]]
];
