var searchData=
[
  ['basedev',['BaseDev',['../classplux_1_1_base_dev.html',1,'plux']]]
];
