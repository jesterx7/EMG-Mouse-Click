var searchData=
[
  ['deleteallschedules',['deleteAllSchedules',['../classplux_1_1_memory_dev.html#a2f47c582e0da921e1dafc067b5b35c6e',1,'plux::MemoryDev']]],
  ['deleteallsessions',['deleteAllSessions',['../classplux_1_1_memory_dev.html#aa310c210ab3c1a0f95b9f4de2ada2170',1,'plux::MemoryDev']]],
  ['deleteschedule',['deleteSchedule',['../classplux_1_1_memory_dev.html#a38f19b8ae4cab7920044ef5f9d1a74c1',1,'plux::MemoryDev']]]
];
