var searchData=
[
  ['onevent',['onEvent',['../classplux_1_1_base_dev.html#ae0c98161b8f1d923e49a734940adc2c6',1,'plux::BaseDev']]],
  ['oninterrupt',['onInterrupt',['../classplux_1_1_base_dev.html#a191117cfea4ff08741f36a84a6b854ff',1,'plux::BaseDev']]],
  ['onrawframe',['onRawFrame',['../classplux_1_1_signals_dev.html#ac1eab5c4660822ee56a4340d5e5e554e',1,'plux::SignalsDev']]],
  ['onsessionevent',['onSessionEvent',['../classplux_1_1_memory_dev.html#aa92838e4efd9630c6f1fca58699222c8',1,'plux::MemoryDev']]],
  ['onsessionrawframe',['onSessionRawFrame',['../classplux_1_1_memory_dev.html#aab489d2025c0ac29eaa3cd2607bab2a7',1,'plux::MemoryDev']]],
  ['ontimeout',['onTimeout',['../classplux_1_1_base_dev.html#a1fde1dddd0641dbc6bd853e4192a6770',1,'plux::BaseDev']]]
];
