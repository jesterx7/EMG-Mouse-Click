var searchData=
[
  ['memorydev',['MemoryDev',['../classplux_1_1_memory_dev.html',1,'plux']]]
];
