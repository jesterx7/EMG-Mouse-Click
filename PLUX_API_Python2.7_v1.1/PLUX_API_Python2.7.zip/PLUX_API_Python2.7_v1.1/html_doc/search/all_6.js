var searchData=
[
  ['getbattery',['getBattery',['../classplux_1_1_base_dev.html#a5a9f884b9db8d10b823ca5c5657518bb',1,'plux::BaseDev']]],
  ['getmemoryused',['getMemoryUsed',['../classplux_1_1_memory_dev.html#a4fcac543fcff8c1d2ac798e0cf168c10',1,'plux::MemoryDev']]],
  ['getproperties',['getProperties',['../classplux_1_1_base_dev.html#afcc3db4150ec601d7cf46defb39345d7',1,'plux::BaseDev']]],
  ['getschedules',['getSchedules',['../classplux_1_1_memory_dev.html#a2303a2484b8a6d7c70fff70bbdf4ea2e',1,'plux::MemoryDev']]],
  ['getsessions',['getSessions',['../classplux_1_1_memory_dev.html#afc64ae4fd93242266e18f34201c3d883',1,'plux::MemoryDev']]],
  ['gettime',['getTime',['../classplux_1_1_memory_dev.html#a9501bfb5170f655fb3ccfe4e969f2639',1,'plux::MemoryDev']]]
];
