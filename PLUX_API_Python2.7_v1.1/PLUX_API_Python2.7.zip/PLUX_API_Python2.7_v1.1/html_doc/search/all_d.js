var searchData=
[
  ['reason',['reason',['../classplux_1_1_event_1_1_disconnect.html#a6802dcec1dabcd1996229ffd41df728e',1,'plux::Event::Disconnect']]],
  ['repeatperiod',['repeatPeriod',['../classplux_1_1_schedule.html#a3126cf04207e5764800718427f8afe63',1,'plux::Schedule']]],
  ['replaysession',['replaySession',['../classplux_1_1_memory_dev.html#ae93384081759901492bbf58f953b93c6',1,'plux::MemoryDev']]],
  ['rtc',['RTC',['../namespaceplux_1_1_event_1_1_clock_source.html#a95359ce860ace91b22fe1d5842179279',1,'plux::Event::ClockSource']]],
  ['running',['running',['../classplux_1_1_schedule_ex.html#a2fbc3c751c58c0c668e1d8fcf546013f',1,'plux::ScheduleEx']]]
];
