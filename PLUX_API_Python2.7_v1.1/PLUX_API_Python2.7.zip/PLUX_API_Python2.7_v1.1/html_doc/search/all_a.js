var searchData=
[
  ['nbits',['nBits',['../classplux_1_1_source.html#a372116773f59b1257c0703943d3c44b1',1,'plux::Source']]],
  ['nframes',['nFrames',['../classplux_1_1_session.html#a11a6003c3eaaa7c7ad70ab341b34aadd',1,'plux::Session']]],
  ['none',['None',['../namespaceplux_1_1_event_1_1_clock_source.html#a4c57384247ec93fb9cdb0a0970872ae1',1,'plux::Event::ClockSource']]],
  ['nrepeats',['nRepeats',['../classplux_1_1_schedule.html#a97b81ba6d7ea96d742425bf328e6088e',1,'plux::Schedule']]]
];
