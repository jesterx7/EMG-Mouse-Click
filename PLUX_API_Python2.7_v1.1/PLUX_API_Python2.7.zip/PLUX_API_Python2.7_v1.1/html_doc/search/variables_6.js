var searchData=
[
  ['port',['port',['../classplux_1_1_source.html#a9bfb83c6745e050610e1e7c1cab66f4a',1,'plux::Source']]],
  ['properties',['properties',['../classplux_1_1_source_ex.html#a71e194d64fd45900c20b485fd4835de5',1,'plux.SourceEx.properties()'],['../classplux_1_1_session.html#a5dd571440ce50d831528d217fb859b12',1,'plux.Session.properties()']]]
];
