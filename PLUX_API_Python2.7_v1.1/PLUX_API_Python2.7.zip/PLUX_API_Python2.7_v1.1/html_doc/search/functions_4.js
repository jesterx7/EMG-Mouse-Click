var searchData=
[
  ['finddevices',['findDevices',['../classplux_1_1_base_dev.html#ab1e58fa0c35fef65e6c52503f8f4273f',1,'plux::BaseDev']]]
];
