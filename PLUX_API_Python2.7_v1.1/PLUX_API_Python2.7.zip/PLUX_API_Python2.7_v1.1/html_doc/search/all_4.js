var searchData=
[
  ['deleteallschedules',['deleteAllSchedules',['../classplux_1_1_memory_dev.html#a2f47c582e0da921e1dafc067b5b35c6e',1,'plux::MemoryDev']]],
  ['deleteallsessions',['deleteAllSessions',['../classplux_1_1_memory_dev.html#aa310c210ab3c1a0f95b9f4de2ada2170',1,'plux::MemoryDev']]],
  ['deleteschedule',['deleteSchedule',['../classplux_1_1_memory_dev.html#a38f19b8ae4cab7920044ef5f9d1a74c1',1,'plux::MemoryDev']]],
  ['diginupdate',['DigInUpdate',['../classplux_1_1_event_1_1_dig_in_update.html',1,'plux::Event']]],
  ['disconnect',['Disconnect',['../classplux_1_1_event_1_1_disconnect.html',1,'plux::Event']]],
  ['duration',['duration',['../classplux_1_1_schedule.html#af5d923724f26b77787d197e496d01d69',1,'plux::Schedule']]]
];
