var classplux_1_1_event_1_1_disconnect =
[
    [ "__init__", "classplux_1_1_event_1_1_disconnect.html#ae47b96317e8d93f2a11518f785a27d85", null ],
    [ "reason", "classplux_1_1_event_1_1_disconnect.html#a6802dcec1dabcd1996229ffd41df728e", null ]
];