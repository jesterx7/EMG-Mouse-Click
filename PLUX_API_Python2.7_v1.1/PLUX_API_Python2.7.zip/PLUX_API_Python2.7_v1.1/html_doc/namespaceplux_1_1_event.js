var namespaceplux_1_1_event =
[
    [ "Clock", "classplux_1_1_event_1_1_clock.html", "classplux_1_1_event_1_1_clock" ],
    [ "DigInUpdate", "classplux_1_1_event_1_1_dig_in_update.html", "classplux_1_1_event_1_1_dig_in_update" ],
    [ "Disconnect", "classplux_1_1_event_1_1_disconnect.html", "classplux_1_1_event_1_1_disconnect" ],
    [ "SchedChange", "classplux_1_1_event_1_1_sched_change.html", "classplux_1_1_event_1_1_sched_change" ],
    [ "Sync", "classplux_1_1_event_1_1_sync.html", "classplux_1_1_event_1_1_sync" ]
];