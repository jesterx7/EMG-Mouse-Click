var classplux_1_1_event_1_1_sync =
[
    [ "__init__", "classplux_1_1_event_1_1_sync.html#a08234e64653003d1d10cf32e2d09c8fa", null ],
    [ "timestamps", "classplux_1_1_event_1_1_sync.html#a21b262cba06b40f55889d2f94c53b70e", null ]
];