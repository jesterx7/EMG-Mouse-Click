var classplux_1_1_base_dev =
[
    [ "__init__", "classplux_1_1_base_dev.html#a0f9961a66eef73149434bb9a0aa177e0", null ],
    [ "close", "classplux_1_1_base_dev.html#af79985152b5df3916e300c2e4c9a4f76", null ],
    [ "getBattery", "classplux_1_1_base_dev.html#a5a9f884b9db8d10b823ca5c5657518bb", null ],
    [ "getProperties", "classplux_1_1_base_dev.html#afcc3db4150ec601d7cf46defb39345d7", null ],
    [ "interrupt", "classplux_1_1_base_dev.html#a233e1a62c0ce7ad27539eca3faf554fe", null ],
    [ "loop", "classplux_1_1_base_dev.html#a933d1125283acd76f32f6e6c390ac570", null ],
    [ "onEvent", "classplux_1_1_base_dev.html#ae0c98161b8f1d923e49a734940adc2c6", null ],
    [ "onInterrupt", "classplux_1_1_base_dev.html#a191117cfea4ff08741f36a84a6b854ff", null ],
    [ "onTimeout", "classplux_1_1_base_dev.html#a1fde1dddd0641dbc6bd853e4192a6770", null ],
    [ "setTimeout", "classplux_1_1_base_dev.html#ae0f2928d449358701473c78bf91b56cf", null ]
];