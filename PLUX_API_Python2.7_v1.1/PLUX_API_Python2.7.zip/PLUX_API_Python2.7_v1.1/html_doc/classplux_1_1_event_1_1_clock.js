var classplux_1_1_event_1_1_clock =
[
    [ "__init__", "classplux_1_1_event_1_1_clock.html#a01cc08aea9de4a02691b5de52b5dcd0a", null ],
    [ "source", "classplux_1_1_event_1_1_clock.html#aaae46a678c8b28e27c2338ec02777ad3", null ],
    [ "value", "classplux_1_1_event_1_1_clock.html#adf182fee350bc8ae362e79d948ddb940", null ]
];