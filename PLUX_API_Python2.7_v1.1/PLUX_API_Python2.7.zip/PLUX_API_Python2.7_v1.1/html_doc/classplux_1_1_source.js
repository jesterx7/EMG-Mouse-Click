var classplux_1_1_source =
[
    [ "__init__", "classplux_1_1_source.html#a53fca382e83e98a8a0462b5388faa792", null ],
    [ "chMask", "classplux_1_1_source.html#afbfb7a079827b4c6c91a977870190d52", null ],
    [ "clas", "classplux_1_1_source.html#adf43e06c6c4d2e93ff8500203cc13150", null ],
    [ "freqDivisor", "classplux_1_1_source.html#a1473345f6fc7aeed33ee3ef4f2a5bcba", null ],
    [ "nBits", "classplux_1_1_source.html#a372116773f59b1257c0703943d3c44b1", null ],
    [ "port", "classplux_1_1_source.html#a9bfb83c6745e050610e1e7c1cab66f4a", null ],
    [ "serialNum", "classplux_1_1_source.html#a2e9efeba1d120a78c7ec72f6d64b08dd", null ]
];